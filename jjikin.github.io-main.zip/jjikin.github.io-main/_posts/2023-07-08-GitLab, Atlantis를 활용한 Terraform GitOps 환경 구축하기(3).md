---

title: GitLab, Atlantis를 활용한 Terraform GitOps 환경 구축하기(3)
date: 2023-07-15 15:33:44 +09:00
categories: [DevOps, gitlab, atlantis]
tags: [gitlab, atlantis, gitops, terraform, iac]
image: /assets/img/posts/image-20230711012040124.png
---



이번 포스트에서는 GitLab, Atlantis 구성 간 겪었던 이슈와 TroubleShooting 과정에 대해 설명합니다.
