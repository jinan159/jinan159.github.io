---
title: ArgoCD 설치 및 SockShop 애플리케이션 배포하기(1)
date: 2023-07-15 15:33:44 +09:00
categories: [DevOps, argocd]
tags: [argocd, deployment, sockshop]
image: /assets/img/posts/image-20230722192343071.png

---



작성 중...

![image-20230722192343071](/assets/img/posts/image-20230722192343071.png)



